package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexao {

    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    private static final String URL =
        "jdbc:mysql://localhost:3306/sistemacomercial";

    private static final String USUARIO = "root";
    private static final String SENHA = "";

    public Connection conectaBanco() {
        try {
            Class.forName(DRIVER);

            Connection conexao = DriverManager.getConnection(
                URL, USUARIO, SENHA
            );

            return conexao;

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(
                null,
                "Driver MySQL não encontrado: " + e.getMessage()
            );
            throw new RuntimeException(e);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                null,
                "Erro ao conectar: " + e.getMessage()
            );
            throw new RuntimeException(e);
        }
    }
}