
package dao;

import conexao.Conexao;
import model.Estado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DaoEstado {

    public List<Estado> getEstados() {

        List<Estado> lista = new ArrayList<>();

        String sql = "SELECT * FROM tb_estado ORDER BY sigla ASC";

        try (
            Connection con = new Conexao().conectaBanco();
            PreparedStatement pstm = con.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery()
        ) {

            while (rs.next()) {

                Estado estado = new Estado();

                estado.setId(rs.getInt("id"));
                estado.setNome(rs.getString("nome"));
                estado.setSigla(rs.getString("sigla"));

                lista.add(estado);
            }

        } catch (SQLException e) {
            throw new RuntimeException(
                "Erro ao buscar estados no banco de dados.", e
            );
        }

        return lista;
    }

    public void salvarEstado(Estado estado) {

        String sql =
            "INSERT INTO tb_estado (nome, sigla) VALUES (?, ?)";

        try (
            Connection con = new Conexao().conectaBanco();
            PreparedStatement pstm = con.prepareStatement(sql)
        ) {

            pstm.setString(1, estado.getNome());
            pstm.setString(2, estado.getSigla());

            pstm.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(
                "Erro ao salvar estado no banco de dados.", e
            );
        }
    }

    public void alterarEstado(Estado estado) {

        String sql =
            "UPDATE tb_estado SET nome=?, sigla=? WHERE id=?";

        try (
            Connection con = new Conexao().conectaBanco();
            PreparedStatement pstm = con.prepareStatement(sql)
        ) {

            pstm.setString(1, estado.getNome());
            pstm.setString(2, estado.getSigla());
            pstm.setInt(3, estado.getId());

            pstm.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(
                "Erro ao alterar estado no banco de dados.", e
            );
        }
    }

    public void excluirEstado(int id) {

        String sql = "DELETE FROM tb_estado WHERE id=?";

        try (
            Connection con = new Conexao().conectaBanco();
            PreparedStatement pstm = con.prepareStatement(sql)
        ) {

            pstm.setInt(1, id);
            pstm.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(
                "Erro ao excluir estado no banco de dados.", e
            );
        }
    }
}
