
package dao;

import conexao.Conexao;
import model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DaoUsuario {

    public void salvarUsuario(Usuario usuario) {

        String sql = "INSERT INTO tb_usuario "
                   + "(nome, email, senha, tipo) VALUES (?, ?, ?, ?)";

        try (
            Connection con = new Conexao().conectaBanco();
            PreparedStatement pstm = con.prepareStatement(sql)
        ) {

            pstm.setString(1, usuario.getNome());
            pstm.setString(2, usuario.getEmail());
            pstm.setString(3, usuario.getSenha());
            pstm.setInt(4, usuario.getTipo());

            pstm.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(
                "Erro ao cadastrar usuario.", e
            );
        }
    }

    public Usuario autenticar(String email, String senha) {

        String sql = "SELECT * FROM tb_usuario "
                   + "WHERE email = ? AND senha = ?";

        try (
            Connection con = new Conexao().conectaBanco();
            PreparedStatement pstm = con.prepareStatement(sql)
        ) {

            pstm.setString(1, email);
            pstm.setString(2, senha);

            try (ResultSet rs = pstm.executeQuery()) {

                if (rs.next()) {

                    Usuario usuario = new Usuario();

                    usuario.setId(rs.getInt("id"));
                    usuario.setNome(rs.getString("nome"));
                    usuario.setEmail(rs.getString("email"));
                    usuario.setTipo(rs.getInt("tipo"));

                    return usuario;
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(
                "Erro ao realizar login.", e
            );
        }

        return null;
    }
}
