package sistemacomercial;

import conexao.Conexao;
import java.sql.Connection;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import view.FrmLogin;

public class SistemaComercial {

    public static void main(String[] args) {

        Conexao conexao = new Conexao();

        try (Connection conn = conexao.conectaBanco()) {

            JOptionPane.showMessageDialog(
                null,
                "Banco conectado com sucesso!"
            );

            SwingUtilities.invokeLater(() -> {
                new FrmLogin().setVisible(true);
            });

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                null,
                "Erro ao conectar com o banco: " + e.getMessage()
            );

        }
    }
}